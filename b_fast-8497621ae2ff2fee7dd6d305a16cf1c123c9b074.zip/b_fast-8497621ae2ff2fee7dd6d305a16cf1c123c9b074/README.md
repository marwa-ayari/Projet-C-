# B_Fast
A software that manages and automates transport agencies work.
# Why is this:
this is a school project to learn c++/QT.
# Original authors:
* Zied razouane
* Ahmed Debbech
* Yacine Ben Abdallah
* Aziz Amdouni
* Wassim Ben Fraj
* Melek Abid

#### This work is based on QT Framework.
