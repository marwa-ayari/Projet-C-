#ifndef HORAIRE_H
#define HORAIRE_H


class horaire
{
public:
    horaire();
};

#endif // HORAIRE_H
